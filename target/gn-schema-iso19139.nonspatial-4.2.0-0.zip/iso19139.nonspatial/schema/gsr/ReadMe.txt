
Validated with XSV 2.10, Xerces J 2.7.1 and XML Spy 2009 (2009-03-02, IGN / France - Nicolas Lesage / Marcellin Prudham)


**************************

Package gsr from Eden repository (http://eden.ign.fr/xsd) 2008-06-26 full release of ISO/TC211 schemas modified as follows :

- spatialReferencing.xsd line2:
xmlns:gml="http://www.opengis.net/gml"
replaced by
xmlns:gml="http://www.opengis.net/gml/3.2"

- spatialReferencing.xsd line9:
namespace="http://www.opengis.net/gml"
replaced by
namespace="http://www.opengis.net/gml/3.2"